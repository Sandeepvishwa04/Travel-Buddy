import express from 'express';
import bodyParser from 'body-parser';
import path from 'path';
import dotenv from 'dotenv';
import pg from 'pg';
import bcrypt from 'bcrypt';
import multer from 'multer';
import fs from 'fs';
import cors from 'cors';

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

// Set up PostgreSQL connection
const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "Travel Buddy",
  password: "sqlvaradha",
  port: 5432,
});

db.connect()
  .then(() => console.log('Database connected successfully'))
  .catch(err => console.error('Database connection error:', err));

// Ensure 'uploads' directory exists
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// Set up file storage for uploads
const storage = multer.diskStorage({
  destination: uploadsDir,
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage, limits: { fileSize: 5 * 1024 * 1024 } });

// Serve static files for uploads and public directory
app.use('/uploads', express.static(uploadsDir));
app.use(express.static(path.join(process.cwd(), 'public')));

// Serve guide and traveler HTML files
app.get('/', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'guide.html'));
});
app.get('/traveler', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'traveler.html'));
});

// Guide Registration
app.post('/submit_guide_registration', upload.single('guide_id_card'), async (req, res) => {
  const { guide_name, guide_phone, guide_id, guide_password, gender } = req.body;
  const guideIdCardPath = req.file ? `uploads/${req.file.filename}` : null; // Store relative path

  try {
    if (!guide_password) return res.status(400).send('Password is required');
    const hashedPassword = await bcrypt.hash(guide_password, 10);

    const query = `
      INSERT INTO guide (name, ph_no, guide_id, password, gender, guide_id_card)
      VALUES ($1, $2, $3, $4, $5, $6)
    `;
    await db.query(query, [guide_name, guide_phone, guide_id, hashedPassword, gender, guideIdCardPath]);

    res.sendFile(path.join(process.cwd(), 'public', 'buddy_post.html'));
  } catch (error) {
    console.error('Error saving guide data:', error);
    res.status(500).send('Server error. Please try again later.');
  }
});

// Buddy Details Submission
app.post('/submit_buddy_details', upload.single('profile_picture'), async (req, res) => {
  const { guide_name, guide_phone, country, state, district, price_per_hour, gender, place } = req.body;
  const profilePicturePath = req.file ? `uploads/${req.file.filename}` : null; // Store relative path

  try {
    const query = `
      INSERT INTO buddy_posts (buddy_name, mobile_no, country, state, district, price_per_hour, profile_picture, gender, place)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `;
    await db.query(query, [guide_name, guide_phone, country, state, district, price_per_hour, profilePicturePath, gender, place]);

    res.send('Buddy details posted successfully!');
  } catch (error) {
    console.error('Error saving buddy details:', error);
    res.status(500).send('Server error. Please try again later.');
  }
});

// Traveler Registration
app.post('/submit_traveler_registration', async (req, res) => {
  const { traveller_name, traveller_email, traveller_password, traveller_phone, gender } = req.body;

  try {
    if (!traveller_password) return res.status(400).send('Password is required');
    const hashedPassword = await bcrypt.hash(traveller_password, 10);

    const query = `
      INSERT INTO traveler (name, email, password, ph_no, gender)
      VALUES ($1, $2, $3, $4, $5)
    `;
    await db.query(query, [traveller_name, traveller_email, hashedPassword, traveller_phone, gender]);

    res.send('Traveler registered successfully!');
  } catch (error) {
    console.error('Error saving traveler data:', error);
    res.status(500).send('Server error. Please try again later.');
  }
});

// Traveler Login
app.post('/submit_traveler_login', async (req, res) => {
  const { traveller_email, traveller_password } = req.body;

  try {
    const query = 'SELECT * FROM traveler WHERE email = $1';
    const result = await db.query(query, [traveller_email]);

    if (result.rows.length === 0) return res.status(400).send('No traveler found with that email');

    const traveller = result.rows[0];
    const isMatch = await bcrypt.compare(traveller_password, traveller.password);
    if (!isMatch) return res.status(400).send('Invalid password');
    
    res.sendFile(path.join(process.cwd(), 'public', 'guide_profiles.html'));

  } catch (error) {
    console.error('Error during traveler login:', error);
    res.status(500).send('Server error. Please try again later.');
  }
});

// Fetch buddy posts
app.get('/api/buddy_posts', async (req, res) => {
  try {
    const result = await db.query('SELECT buddy_name, mobile_no, country, state, district, place, profile_picture, price_per_hour FROM buddy_posts');
    res.json(result.rows); // Send buddy posts as JSON
  } catch (error) {
    console.error('Error fetching buddy posts:', error);
    res.status(500).json({ error: 'Failed to retrieve buddy posts' });
  }
});

// Serve guide profiles HTML on successful login
app.get('/guide_profiles', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'guide_profiles.html'));
});

// Start server
const port = 3001;

const server = app.listen(port, () => {
  console.log(`Server running on port ${port}`);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`Port ${port} is busy. Please try another port or close the application using this port.`);
    process.exit(1);
  } else {
    console.error(err);
  }
});
